var app = angular.module('MainApp', []);
app.controller('MainCtrl', ['$scope','$http', function($scope,$http){
$scope.submitFn=function(){
  var wikiSearchUrl="http://en.wikipedia.org/w/api.php?action=query&format=json&list=search&utf8=1&srsearch="+$scope.searchbar+"&srprop=redirecttitle&origin=*&gsrsearch=";
   $.get(wikiSearchUrl,function(data){
     $scope.result=[];
     $scope.result=data.query.search;
     $scope.resultFunction($scope.result);
  

});
 }

 $scope.resultFunction=function(val){
   var inHTML = "";

$.each(val, function(index, value){
  console.log(value);
    var newItem ="<h3 class='h3style'> <a href='https://en.wikipedia.org/wiki/"+value.title+"' target='_blank'>"+value.title+"</a></h3>"
    inHTML += newItem;  

  
  
   });
     $('#resultpills').show();
     $('#repeatId').html(inHTML);
     $('.changesearch').css("top", "10%");
 }
  
}]);
 function searchToggle(obj, evt){
            var container = $(obj).closest('.search-wrapper');

            if(!container.hasClass('active')){
                  container.addClass('active');
                  evt.preventDefault();
                $('.search-input').focus();
            }
            else if(container.hasClass('active') && $(obj).closest('.input-holder').length == 0){
                  container.removeClass('active');
              
                  // clear input
                  container.find('.search-input').val('');
                 $('#resultpills').hide();
     $('.changesearch').css("top", "65%");
                  // clear and hide result container when we press close
                  container.find('.result-container').fadeOut(100, function(){$(this).empty();});
            }
        }