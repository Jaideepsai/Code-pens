  $.get("http://ipinfo.io", function(response) {
    var latitude=response.loc.split(",")[0];
     var longitude=response.loc.split(",")[1];
    var cityName=response.city;
    $("#cityName").append(cityName);
    $.get("http://api.openweathermap.org/data/2.5/weather?lat="+latitude+"&lon="+longitude+"&APPID=4977350814aedb326bcac1a8e7ce9c61",function(data) {
    var tempMin=data.main.temp_min;
    var tempCelsius =    Math.round(((tempMin) - 273.15));
       $("#temperature").html(tempCelsius+"&deg");
      $("#celsius").click(function(){
       $("#temperature").html(tempCelsius+"&deg");
      });
       $("#kelvin").click(function(){
       $("#temperature").html(tempMin+"&deg");
      });
    
});
    
    $.get("https://www.googleapis.com/customsearch/v1?q="+cityName+"&cx=002147687294042565255%3Ami_qceumryq&imgSize=xxlarge&imgType=photo&num=10&safe=off&searchType=image&key=AIzaSyDsjJ6BT1eNdZqw9U1CDQr9ETYkD9BArcc",function(response) {
      var imageUrl=response.items[0].link;
  console.log(imageUrl);
      $('body').css('background-image', 'url('+imageUrl+')');
    });
    
}, "jsonp")

$('.btn-toggle').click(function() {
    $(this).find('.btn').toggleClass('active');   
    if ($(this).find('.btn-primary')) {
    	$(this).find('.btn').toggleClass('btn-primary');
    }    
    $(this).find('.btn').toggleClass('btn-default');
       
});