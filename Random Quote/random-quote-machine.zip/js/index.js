angular.module('toolbarDemo1', ['ngMaterial']).controller('AppCtrl', function($scope,$http) {
  $scope.getQuote=[];
  var count=0;
  $scope.defaultquote=function(){
 $http.get("https://quotesondesign.com/wp-json/posts?filter[orderby]=rand&filter[posts_per_page]=42").then(function(response) {
   $scope.getQuote=response.data;
  $("blockquote h3").append(response.data[0].content);
     $("blockquote footer").append(response.data[0].title);
    });
  }
  $scope.defaultquote();
  $scope.nextquote=function(){
      $("blockquote h3").empty();
     $("blockquote footer").empty();
    if(count<=42){
    count=count+1;
      console.log($scope.quote);
       $("blockquote h3").append($scope.getQuote[count].content);
     $("blockquote footer").append($scope.getQuote[count].title);
    }
    else{
      count=0;
       $("blockquote h3").append($scope.getQuote[count].content);
     $("blockquote footer").append($scope.getQuote[count].title);
    }
  }
  $scope.prevQuote=function(){
    $("blockquote h3").empty();
     $("blockquote footer").empty();
    if(count<=42 && count>0){
    count=count-1;
       $("blockquote h3").append($scope.getQuote[count].content);
     $("blockquote footer").append($scope.getQuote[count].title);
    }
    else{
      count=0;
       $("blockquote h3").append($scope.getQuote[count].content);
     $("blockquote footer").append($scope.getQuote[count].title);
    }
    }
});